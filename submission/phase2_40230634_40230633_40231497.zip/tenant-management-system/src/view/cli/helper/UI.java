package view.cli.helper;

import java.util.HashMap;

/**
 * @author mkjodhani
 * @version 1.0
 * @project Tenant Management System
 * @since 07/03/23
 */
public class UI {
    public void showTableView(HashMap<String,String> keyPairs){

    }
}
